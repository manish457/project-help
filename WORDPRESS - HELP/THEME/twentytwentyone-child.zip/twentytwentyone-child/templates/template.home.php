<?php
/*
 * Template Name: Home template
 * Description: Template file for the Home Page Only
 */
 
get_header(); ?>

<?php get_footer(); ?>
